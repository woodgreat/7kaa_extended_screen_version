#!/bin/bash
# 7kaa_hd Linux 一键安装脚本

set -e

echo "======================================"
echo "  7kaa_hd - 高分辨率补丁安装"
echo "======================================"
echo ""

# 检查系统类型
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
else
    DISTRO="unknown"
fi

echo "检测到系统: $DISTRO"
echo ""

# 安装依赖
echo ">>> 安装依赖..."
case "$DISTRO" in
    ubuntu|debian|linuxmint)
        sudo apt-get update
        sudo apt-get install -y libsdl2-2.0-0 libopenal1 libenet7 libcurl4
        ;;
    fedora|centos|rhel)
        sudo dnf install -y SDL2 openal-soft enet libcurl
        ;;
    arch|manjaro)
        sudo pacman -S --noconfirm sdl2 openal enet curl
        ;;
    *)
        echo "未知发行版，请手动安装: SDL2, OpenAL, enet, curl"
        read -p "按回车继续..."
        ;;
esac

echo ""
echo ">>> 复制游戏文件..."

# 确定安装位置
INSTALL_DIR="$HOME/.local/share/7kaa_hd"
mkdir -p "$INSTALL_DIR"

# 复制 data 目录（包含 7kaa_hd 和配置文件）
cp -r data "$INSTALL_DIR/"

# 复制配置文件到用户目录（如果已存在则不覆盖）
if [ ! -f "$HOME/.7kaa/config.ini" ]; then
    mkdir -p "$HOME/.7kaa"
    cp data/config.ini "$HOME/.7kaa/config.ini"
    echo "已创建默认配置文件: ~/.7kaa/config.ini"
fi

echo "文件已复制到: $INSTALL_DIR"
echo ""

# 创建启动脚本
mkdir -p "$HOME/.local/bin"
cat > "$HOME/.local/bin/7kaa_hd" << 'LAUNCHER'
#!/bin/bash
cd "$HOME/.local/share/7kaa_hd/data"
exec ./7kaa_hd "$@"
LAUNCHER
chmod +x "$HOME/.local/bin/7kaa_hd"

echo "启动脚本已创建: ~/.local/bin/7kaa_hd"
echo ""

# 创建桌面快捷方式
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/7kaa_hd.desktop" << DESKTOP
[Desktop Entry]
Name=Seven Kingdoms HD
Comment=Seven Kingdoms: Ancient Adversaries - HD Edition
Exec=$HOME/.local/bin/7kaa_hd
Icon=$INSTALL_DIR/data/IMAGE/7K_ICON.BMP
Terminal=false
Type=Application
Categories=Game;StrategyGame;
DESKTOP

echo "桌面快捷方式已创建"
echo ""
echo "======================================"
echo "  安装完成！"
echo "======================================"
echo ""
echo "运行方式："
echo "  命令行: 7kaa_hd"
echo "  桌面:   应用菜单搜索 'Seven Kingdoms HD'"
echo ""
echo "高分辨率设置："
echo "  编辑 ~/.7kaa/config.ini 修改分辨率"
echo "  当前默认: 1920x1080"
echo ""
echo "卸载方式："
echo "  rm -rf $INSTALL_DIR"
echo "  rm -f ~/.local/bin/7kaa_hd"
echo "  rm -f ~/.local/share/applications/7kaa_hd.desktop"
echo ""
